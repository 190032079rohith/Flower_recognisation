# Flower-Recognition
This project classifies different types of flowers
In this project I have used machine learning algoithm :CNN (Convolution Neural Network) to determine the type of flower. 
A Dataset containing 4,326 images of different flowers,downloaded from Kaggle,is used to train the neural network with 3 hidden convolution layers.
Firstly,images are resized to 100X100 so that every image is of same size.
Then, after preprocessing of images ,they are labelled to be classified as following 5 categories : 
1.Daisy
2.Dandelion
3.Rose
4.Sunflower
5.Tulip
Then,dataset is fitted in the neural network model created.
The accuracy of classification by CNN model used is more than 70% on test set.
Then the model is tested on some random images from the internet giving 4 out of 5 predictions correct.




The Dataset used can be downloaded from the following link:
https://www.kaggle.com/alxmamaev/flowers-recognition#flowers.zip
